export default function Login() {
  return (
    <div>
      <h1>Login</h1>
    </div>
  );
}


