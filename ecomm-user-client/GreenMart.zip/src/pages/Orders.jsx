export default function Orders() {
  return (
    <div>
      <h1>Orders</h1>
    </div>
  );
}


