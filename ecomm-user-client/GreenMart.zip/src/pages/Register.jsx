export default function Register() {
  return (
    <div>
      <h1>Register</h1>
    </div>
  );
}


